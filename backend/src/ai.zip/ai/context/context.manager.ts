import { AiContext } from '../types';
import { aiLogger } from '../utils/logger';

class ContextManager {
  // In-memory store keyed by userId or sessionId
  private contexts: Map<string, AiContext>;

  constructor() {
    this.contexts = new Map();
  }

  public getContext(userId: string): AiContext {
    let context = this.contexts.get(userId);
    if (!context) {
      // Return default anonymous context if not found
      context = {
        userId,
        role: 'guest',
        preferredLanguage: 'en',
        stadium: 'Unknown',
        accessibilityPreferences: []
      };
      this.contexts.set(userId, context);
      aiLogger.debug(`Created default context for ${userId}`);
    }
    return context;
  }

  public updateContext(userId: string, updates: Partial<AiContext>): void {
    const existing = this.getContext(userId);
    this.contexts.set(userId, { ...existing, ...updates });
    aiLogger.debug(`Updated context for ${userId}`, updates);
  }
}

export const contextManager = new ContextManager();
