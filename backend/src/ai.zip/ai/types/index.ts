export interface AiContext {
  userId: string;
  role: 'fan' | 'organizer' | 'security' | 'guest';
  preferredLanguage: string;
  stadium: string;
  match?: string;
  accessibilityPreferences: string[];
}

export interface PromptTemplate {
  systemPrompt: string;
  contextData: Partial<AiContext>;
  userMessage: string;
}

export interface StructuredSchema {
  type: string;
  properties: Record<string, any>;
  required?: string[];
}
