import dotenv from 'dotenv';

dotenv.config();

export const AI_CONFIG = {
  GEMINI_API_KEY: process.env.GEMINI_API_KEY || '',
  DEFAULT_MODEL: 'gemini-2.5-flash',
  MAX_TOKENS: 1024,
  TEMPERATURE: 0.7,
};
