import { AiContext, PromptTemplate } from '../types';

export const buildSystemPrompt = (context: AiContext): string => {
  return `You are the FIFA World Cup 2026 AI Stadium Companion.
Current User Context:
- Role: ${context.role}
- Language: ${context.preferredLanguage}
- Stadium: ${context.stadium}
${context.match ? `- Match: ${context.match}` : ''}
${context.accessibilityPreferences.length > 0 ? `- Accessibility Needs: ${context.accessibilityPreferences.join(', ')}` : ''}

Provide helpful, accurate, and concise assistance based on this context.`;
};

export const buildPrompt = (template: PromptTemplate): string => {
  return `${template.systemPrompt}
  
User Request: ${template.userMessage}`;
};
