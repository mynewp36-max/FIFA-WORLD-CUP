export const aiLogger = {
  info: (message: string, meta?: any) => {
    console.log(`[AI INFO] ${message}`, meta ? JSON.stringify(meta) : '');
  },
  error: (message: string, error: any) => {
    console.error(`[AI ERROR] ${message}`, error);
  },
  debug: (message: string, meta?: any) => {
    if (process.env.NODE_ENV !== 'production') {
      console.log(`[AI DEBUG] ${message}`, meta ? JSON.stringify(meta) : '');
    }
  }
};
