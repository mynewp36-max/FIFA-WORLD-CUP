import { GoogleGenAI } from '@google/genai';
import { AI_CONFIG } from '../config';
import { aiLogger } from '../utils/logger';

class GeminiClient {
  private static instance: GeminiClient;
  private client: GoogleGenAI;

  private constructor() {
    if (!AI_CONFIG.GEMINI_API_KEY) {
      aiLogger.error('Initialization Failed', new Error('GEMINI_API_KEY is not defined in the environment.'));
    }
    
    this.client = new GoogleGenAI({
      apiKey: AI_CONFIG.GEMINI_API_KEY
    });
    
    aiLogger.info('Gemini Client initialized.');
  }

  public static getInstance(): GeminiClient {
    if (!GeminiClient.instance) {
      GeminiClient.instance = new GeminiClient();
    }
    return GeminiClient.instance;
  }

  public getClient(): GoogleGenAI {
    return this.client;
  }
}

export const getGeminiClient = () => GeminiClient.getInstance().getClient();
