import { getGeminiClient } from '../client/gemini.client';
import { contextManager } from '../context/context.manager';
import { buildSystemPrompt, buildPrompt } from '../prompts/prompt.builder';
import { AI_CONFIG } from '../config';
import { aiLogger } from '../utils/logger';

export class AiService {
  
  public static async generateResponse(userId: string, userMessage: string): Promise<string> {
    try {
      const client = getGeminiClient();
      const context = contextManager.getContext(userId);
      const systemPrompt = buildSystemPrompt(context);
      const finalPrompt = buildPrompt({ systemPrompt, contextData: context, userMessage });
      
      aiLogger.debug('Generating response for user', { userId });
      
      const response = await client.models.generateContent({
        model: AI_CONFIG.DEFAULT_MODEL,
        contents: finalPrompt,
        config: {
          temperature: AI_CONFIG.TEMPERATURE,
        }
      });
      
      return response.text || '';
    } catch (error) {
      aiLogger.error('Error generating response', error);
      throw error;
    }
  }

  public static async generateStructuredResponse(userId: string, userMessage: string, schema: any): Promise<any> {
    try {
      const client = getGeminiClient();
      const context = contextManager.getContext(userId);
      const systemPrompt = buildSystemPrompt(context);
      const finalPrompt = buildPrompt({ systemPrompt, contextData: context, userMessage });
      
      aiLogger.debug('Generating structured response for user', { userId });
      
      const response = await client.models.generateContent({
        model: AI_CONFIG.DEFAULT_MODEL,
        contents: finalPrompt,
        config: {
          temperature: 0.1, // Lower temperature for structured output
          responseMimeType: 'application/json',
          responseSchema: schema
        }
      });
      
      if (!response.text) return null;
      return JSON.parse(response.text);
    } catch (error) {
      aiLogger.error('Error generating structured response', error);
      throw error;
    }
  }

  public static async summarize(text: string): Promise<string> {
    try {
      const client = getGeminiClient();
      const prompt = `Summarize the following text concisely:\n\n${text}`;
      
      const response = await client.models.generateContent({
        model: AI_CONFIG.DEFAULT_MODEL,
        contents: prompt,
      });
      
      return response.text || '';
    } catch (error) {
      aiLogger.error('Error in summarize', error);
      throw error;
    }
  }

  public static async translate(text: string, targetLanguage: string): Promise<string> {
    try {
      const client = getGeminiClient();
      const prompt = `Translate the following text to ${targetLanguage}:\n\n${text}`;
      
      const response = await client.models.generateContent({
        model: AI_CONFIG.DEFAULT_MODEL,
        contents: prompt,
      });
      
      return response.text || '';
    } catch (error) {
      aiLogger.error('Error in translate', error);
      throw error;
    }
  }
}
